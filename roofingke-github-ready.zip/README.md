# Roofing.Ke — New Zealand Stone Coated Roofing Tiles

Official website for **Roofing.Ke** (Beatific) — Syokimau, off Mombasa Road, Kenya.

- 50-year warranty
- Pricing: KSh 650 / 620 / 600 per piece
- WhatsApp: 0790 056 261

## Deploy to Vercel (GitHub method — recommended)

### 1. Push this folder to GitHub

1. Create a **new** repository on GitHub (e.g. `roofingke`)
2. Do **not** add a README or .gitignore on GitHub (this folder already has them)
3. On your computer, open a terminal in this folder and run:

```bash
git init
git add .
git commit -m "Roofing.Ke website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/roofingke.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username.

### 2. Connect to Vercel

1. Go to [https://vercel.com/new](https://vercel.com/new)
2. Click **Import Git Repository**
3. Choose the `roofingke` repo
4. Leave settings as default:
   - Framework Preset: **Other** (or leave blank)
   - Root Directory: `.` (leave empty)
   - Build Command: leave **empty**
   - Output Directory: leave **empty**
5. Click **Deploy**

### 3. Done

Vercel will give you a live URL like `roofingke.vercel.app`.

No build step is required — this is a static HTML site.

## Local preview

Open `index.html` in a browser, or run:

```bash
npx serve .
```

## Project structure

```
/
├── index.html      # Full website
├── images/         # All product & project photos
├── vercel.json     # Vercel config (static, no framework)
├── .gitignore
└── README.md
```
